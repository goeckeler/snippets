import jrobots.simulation.simulationObjects.JRobot2016A;
import jrobots.utils.Angle;

/**
 * He is the oldest of all race pilots.
 */
public class EmptyRacer extends JRobot2016A {
	private static final long serialVersionUID = 1L;

	Angle driveDir = Angle.EAST;
	
	@Override
	protected void actions() {
		driveDir = driveDir.add(new Angle(Math.random()-0.5, "d"));
		this.setAutopilot(driveDir, 1);
	}

}
